# NeuronPerf

A library for benchmarking machine learning models on accelerators.

## Documentation

https://awsdocs-neuron.readthedocs-hosted.com/en/latest/neuron-guide/neuronperf/index.html