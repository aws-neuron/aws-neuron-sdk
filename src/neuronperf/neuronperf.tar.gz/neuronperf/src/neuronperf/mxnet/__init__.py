from neuronperf.mxnet.mxnet import benchmark, compile
