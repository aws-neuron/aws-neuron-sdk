from neuronperf.cpu.cpu import benchmark
